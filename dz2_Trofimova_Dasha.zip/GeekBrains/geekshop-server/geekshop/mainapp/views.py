from django.shortcuts import render


# Create your views here.
def index(request):
    menu = {'title': 'Магазин'}
    return render(request, 'mainapp/index.html', menu)


def products(request):
    return render(request, 'mainapp/products.html')


def contact(request):
    return render(request, 'mainapp/contact.html')


def context(request):
    context = {
        'title': 'test content',
        'header': 'Добро пожаловать на сайт',
        'username': 'Дарья',
        'products': [
            {'name': 'Стулья', 'price': 5467},
            {'name': 'Диваны', 'price': 12345},
            {'name': 'Столы', 'price': 55432},
        ]
    }
    return render(request, 'mainapp/test_context.html', context)


def menu(request):
    links_menu = [
        {'href': 'products_all', 'name': 'все'},
        {'href': 'products_home', 'name': 'дом'},
        {'href': 'products_office', 'name': 'офис'},
        {'href': 'products_classic', 'name': 'классика'},
        ]

    return render(request, 'inc_categories_menu.html', links_menu)