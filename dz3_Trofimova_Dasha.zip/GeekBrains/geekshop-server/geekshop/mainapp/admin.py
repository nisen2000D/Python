from django.contrib import admin
from mainapp.models import ProductCategory, Products

# Register your models here.

admin.site.register(ProductCategory)
admin.site.register(Products)
