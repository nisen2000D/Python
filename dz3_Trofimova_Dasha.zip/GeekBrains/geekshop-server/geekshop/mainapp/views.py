from django.shortcuts import render

from mainapp.models import Products, ProductCategory
# Create your views here.
def index(request):
    menu = {'title': 'Магазин'}
    return render(request, 'mainapp/index.html', menu)


def products(request, pk=None):
    print(pk)
    return render(request, 'mainapp/products.html')



def contact(request):
    return render(request, 'mainapp/contact.html')


def context(request):
    context = {
        'title': 'test content',
        'header': 'Добро пожаловать на сайт',
        'username': 'Дарья',
        'products': [
            {'name': 'Стулья', 'price': 5467},
            {'name': 'Диваны', 'price': 12345},
            {'name': 'Столы', 'price': 55432},
        ]
    }
    return render(request, 'mainapp/test_context.html', context)


def menu(request):
    links_menu = [
        {'href': 'products_all', 'name': 'все'},
        {'href': 'products_home', 'name': 'дом'},
        {'href': 'products_office', 'name': 'офис'},
        {'href': 'products_modern', 'name': 'модерн'},
        {'href': 'products_classic', 'name': 'классика'},
        ]

    menu = [
        {'href': 'index', 'name': 'главная'},
        {'href': 'products:index', 'name': 'продукты'},
        {'href': 'contact', 'name': 'контакты'},
    ]

    return render(request, 'inc_categories_menu.html', links_menu, menu)


def main(request):
    title = 'главная'
    product = Products.objects.all()[:4]
    content = {'title': title, 'products': product}
    return render('mainapp/content.html', content)